<?php
define('NOVUSAPI',1);

require_once('config.php');

if (!empty($_GET['l']) && $_GET['l']=='wjc934wh') {
	$k1 = $_GET['md'];
} else {
	if ($argc>1) {
         	$k1 = $argv[1];
	}
}

//echo $k1.PHP_EOL;
$q = 'select * from doctors where specialization="'.$k1.'"';


//echo $q.PHP_EOL; die;
$array = [];
header('Content-Type: application/json');

if ($result = $conn->query($q)) {
      while($row=$result->fetch_assoc()) {
           array_push($array, $row);
      }
      echo json_encode($array);
//var_dump($array); die;
} else {
      echo '(empty)';
}
 


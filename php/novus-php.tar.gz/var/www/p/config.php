<?php
if (!defined("NOVUSAPI")) die;

$servername = "localhost";
$username = "hspaceuser";
$password = "p@ssw0rD";

// Create connection
$conn = new mysqli($servername, $username, $password);

$result = $conn->query('use hspace');

// Check connection
if ($conn->connect_error) {
  die("Connection failed: ");
}
// echo "Connected successfully";

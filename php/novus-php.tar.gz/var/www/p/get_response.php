<?php
define('NOVUSAPI',1);

require_once('config.php');

if (!empty($_GET['l']) && $_GET['l']=='wjc934wh') {
	$k1 = $_GET['k1'];
	$k2 = $_GET['k2'];
	$f = $_GET['fid'] ?? null;
} else {
	if ($argc>2) {
		$k1 = $argv[1];
		$k2 = $argv[2];
		$f = $argv[3] ?? null;
	}
}

//echo $k1.PHP_EOL;
//echo $k2.PHP_EOL;
//echo $f.PHP_EOL;
$q = 'select * from disease_chat_tree';
$from = '';
if (empty($f) || is_null($f)) { 
  $q .= ' where id=1';  
} elseif (trim($f)=="1")  {
  $q .= ' where id=2';  
} elseif (trim($f)=="2")  {
  $q .= ' where id=3';  
} else {
   $from = ' and (from_id>='.$f.' or from_id<3)' ;


$key_condition1 = '';
if(!empty($k1)) {
    $keys = explode(' ', $k1);
//var_dump($keys); echo PHP_EOL;
    foreach($keys as $kx) {
        $key_condition1 .= ' keyword like "%'.$kx.'%" or'; 
    }
    $key_condition1 = ' (' . substr($key_condition1, 0, strlen($key_condition1)-2) .')';
} 

$key_condition2 = '';
if (!empty($k2)) {
    $keys = explode(' ', $k2);
//var_dump($keys); echo PHP_EOL;
    foreach($keys as $kx) {
       $key_condition2 .= ' keyword2 like "%'.$kx.'%" or';   
    }
    $key_condition2 = ' or ('.substr($key_condition2, 0, strlen($key_condition2)-2).')';
}
 
   if (empty($k1) && empty($k2)) {
      $q .= ' where id=1';
   } else {
      $q .= ' where ('. $key_condition1 . $key_condition2. ')' . $from;
   }
}

//echo $q.PHP_EOL; die;
$array = [];
header('Content-Type: application/json');

if ($result = $conn->query($q)) {
      while($row=$result->fetch_assoc()) {
           array_push($array, $row);
      }
	$array2 = array("list"=>$array);
      echo json_encode($array2);
//var_dump($array);
} else {
      echo '(empty)';
}
 


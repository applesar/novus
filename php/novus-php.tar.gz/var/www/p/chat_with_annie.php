<?php

if (empty($_GET['chat'])) {
	
	$a = file_get_contents('https://www.pasakay-puv.net/get_response.php?l=wjc934wh&k1=&k2=&fid=');

} else {
	$k2 = $k1 = urlencode($_REQUEST['chat'] ?? "");
        $fid = $_REQUEST['f'] ?? null;
        $chain =  ($_REQUEST['chain'] ?? "");
//echo 
	$q = 'https://www.pasakay-puv.net/get_response.php?l=wjc934wh&k1='.$k1.'&k2='.$k2.'&fid='.$fid;
	$a = file_get_contents($q);

}

//header("Conten-type: plain/text");
//echo $a.PHP_EOL;
$a = json_decode($a);

$chainArray = explode(',',$chain);

foreach($chainArray as $x => $j) {
	$chainArray[$x] = $j + 0;
}


header("Conten-type: plain/text");
//echo '<pre>';
//var_dump($chainArray); 
//var_dump($a); die;
$newChat = null;
foreach ($a as $x => $j) {
	if (in_array($j->id, $chainArray)) continue; 
	$newChat = $j;
	break;
}

//var_dump($newChat); die;

if ($newChat) {
	$consult = false;
	if (substr($newChat->response, 0, 10)=="<consult: ") {
		$consult = substr($newChat->response, -3, 2);
		header('Location: https://www.pasakay-puv.net/get_consult.php?l=wjc934wh&md='.$consult);	
		exit;
        }
	if (substr($newChat->response, 0, 10)=="<test: ") {
		$consult = substr($newChat->response, 7);
		header('Location: https://www.pasakay-puv.net/get_tested.php?l=wjc934wh&test='.$consult);	
		exit;
        }

$chain = $chain.(empty($chain) ? '' : ',').$fid;
$lang = ($_REQUEST['lang'] ?? "1");
$r = ($lang=="1") ? $newChat->response : (($lang=="2") ? $newChat->response2 : $newChat->response3);
?>

<!DOCTYPE html>
<HTML>
<head>
</head>
<body>
<div class="annie_talks">
    <?= $r	 ?>
</div>
<form method="get" action="chat_with_annie.php">
<input type="hidden" name="f" value="<?= $newChat->id ?>"/>
<input type="hidden" name="lang" value="<?= $lang ?>"/>
<input type="hidden" name="chain" value="<?= $chain ?>"/>
<div class="my_talk">
    <input name="chat" type="text" value="">
    <input type="submit" value="send">
</div>
</form>
</body>
</html>

<?php 
} else {
?>

<!DOCTYPE html>
<HTML>
<head>
</head>
<body>
<div class="annie_talks">
    I cannot understand that. Please try again.
</div>
<form method="get" action="chat_with_annie.php">
<input type="hidden" name="f" value="<?= $fid ?>"/>
<input type="hidden" name="lang" value="<?= $lang ?>"/>
<input type="hidden" name="chain" value="<?= $chain ?>"/>
<div class="my_talk">
    <input name="chat" type="text" value="">
    <input type="submit" value="send">
</div>
</form>
</body>
</html>

<?php
}
?>


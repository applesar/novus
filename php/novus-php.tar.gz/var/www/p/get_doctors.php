<?php
define("NOVUSAPI",1);

require_once('config.php');

$q = 'select * from doctors';

if ($result = $conn->query($q)) {
    while($row = $result->fetch_object()) {
 	var_dump($row);
    }
}
